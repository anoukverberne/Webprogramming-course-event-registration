<script
  src="https://code.jquery.com/jquery-3.7.1.js"
  integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4="
  crossorigin="anonymous"></script>

<script
  src="https://code.jquery.com/ui/1.13.2/jquery-ui.min.js"
  integrity="sha256-lSjKY0/srUM9BE3dPm+c4fBo1dky2v27Gdjm2uoZaL0="
  crossorigin="anonymous"></script>

  <link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/flick/jquery-ui.css">
  <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
  <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>

  <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
  <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>

<?php
$db_host = 'localhost';
$db_user = 'root';
$db_password = 'root';
$db_db = 'webprogramming';

$mysqli = @new mysqli(
    $db_host,
    $db_user,
    $db_password,
    $db_db
);

if ($mysqli->connect_error) {
    echo 'Errno: ' . $mysqli->connect_errno;
    echo '<br>';
    echo 'Error: ' . $mysqli->connect_error;
    exit();
}

echo 'Success: A proper connection to MySQL was made.';
echo '<br>';
echo 'Host information: ' . $mysqli->host_info;
echo '<br>';
echo 'Protocol version: ' . $mysqli->protocol_version;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $email = $_POST['email'];
    $phonenumber = $_POST['phonenumber'];
    $birthdate = $_POST['selectedDate'];
    $gender = $_POST['gender'];
    $companyname = $_POST['companyName'];
    $functioncompany = $_POST['Function'];
    $arrivaldate = $_POST['selectedDate2'];
    $eventattendance = $_POST['Eventattandance'];

    $selectedTickets =[]; 
    if (isset($_POST['checkbox-1'])) {
        $selectedTickets[] = 'Day ticket';
    }
    if (isset($_POST['checkbox-2'])) {
        $selectedTickets[] = 'Week ticket';
    }
    if (isset($_POST['checkbox-3'])) {
        $selectedTickets[] = 'Week ticket + hotel';
    }

    // SQL query to insert data into the "test3" table
    $insertQuery = "INSERT INTO test3 (voornaam, achternaam, email, phonenumber, birthdate, gender, companyname, functioncompany,typeofticket) VALUES ('$firstName', '$lastName', '$email', '$phonenumber', '$birthdate', '$gender', '$companyname', '$functioncompany', '$selectedTickets')";

    // Execute the query
    if ($mysqli->query($insertQuery) === TRUE) {
        echo "Record added successfully.";

    } 
    else {
        echo "Error: " . $insertQuery . "<br>" . $mysqli->error;
    }

    if (!empty($selectedTickets)) {
      echo "<h2>Selected Tickets:</h2>";
      echo "<ul>";
      foreach ($selectedTickets as $ticket) {
          echo "<li>$ticket</li>";
      }
      echo "</ul>";} 
    else {
      echo "<p>No tickets selected.</p>";
  }
}

// Close the database connection
$mysqli->close();

// Close the database connection
$mysqli->close();
?>
<!-- Title -->
<!DOCTYPE html>
<head>
    <title> Event registration form </title>
    <link rel="stylesheet" href="styleweb.css">
    </head>
<!--Title-->
<body>
  <div class="container">
    <div class="box-1">
    <h1>Event registration form</h1>
    <p> Welcome to our event registration form! 
      Here, you can securely sign up to attend our exciting upcoming event. 
      Whether you're a seasoned participant or new to our community, we're thrilled to have you join us. By filling out this form, you'll gain access to a wealth of opportunities, including insightful sessions, networking events, and engaging activities. 
      Don't miss out on this chance to connect, learn, and grow with us. Register now and be part of an unforgettable experience!</p>
    </div>

<!--Registration form-->
  <form action="index.php" method="POST" class="my-form"> 
    <div class="form-group1">
      <label>First Name</label>
     <input type="text" name="firstName" placeholder="Enter your first name"> 
    </div>
    <div class="form-group1">
      <label>Last Name</label>
      <input type="text" name="lastName" placeholder="Enter your last name"> 
    </div>
    <div class="form-group1">
      <label>Email</label>
      <input type="email" name="email" placeholder="Enter your email address"> 
    </div>
    <div class="form-group1">
      <label>Phonenumber</label>
      <input type="tel" id="phone" name="phonenumber" placeholder="Enter your phone number">
 <!-- Telephone number -->  
    <link rel="stylesheet" href="build/css/demo.css">
    <link rel="stylesheet" href="build/css/intlTelInput.css">
    <script src="build/js/intlTelInput.js"> </script>
    </div>

 <!-- Registration form with datepicker -->
    <div class="form-group1">
      <label for="datepicker">Birthdate</label>
      <input type="text" id="datepicker" name="selectedDate">
    </div>

  <!-- Add other form fields as needed -->
    <div class="form-group1">
      <label>Gender</label>
      <select name ="gender">
        <option value= "male">Male</option>
        <option value= "female">Female</option>
        <option value= "other">Other</option>
      </select>
    </div>

    <div class="form-group1">
      <label>Company name</label>
      <input type="text" name="companyName" placeholder="Enter your Company name"> 
    </div>

    <div class="form-group1">
      <label>Function</label>
      <input type="text" name="Function" placeholder="Enter your Function"> 
    </div>

<div class="form-group1">
  <label>Will you attend the event?</label>
      <select name ="Eventattandance">
        <option value= "yes">Yes</option>
        <option value= "no">No</option>
      </select>
</div>

<div class="form-group1">
<fieldset>
    <legend>What kind of ticket do you want to buy </legend>
    <label for="checkbox-1">Day ticket</label>
    <input type="checkbox" name="checkbox-1[]" id="checkbox-1">
    <label for="checkbox-2">Week ticket</label>
    <input type="checkbox" name="checkbox-2[]" id="checkbox-2">
    <label for="checkbox-3">Week ticket + hotel</label>
    <input type="checkbox" name="checkbox-3[]" id="checkbox-3">
  </fieldset>
</div>
</form>
<div class="header-2">
<h2> Travel information </h2>
<p> If you filled in that you would like a hotel as well, please fill in the questions below!</p>
</div>

<form action="index.php" method="POST" class="my-form2"> 
<div class="form-group2">
  <label for="datepicker">When will you arrive?</label>
  <input type="text" id="datepicker2" name="selectedDate2">
</div>

  <div class="form-group2">
  <label>Do you need transportation?</label>
      <select name ="Transportation">
        <option value= "yes">Yes</option>
        <option value= "no">No</option>
      </select>
</div>

<div class="form-group2">
<fieldset>
    <legend>Hotel Ratings: </legend>
    <label for="checkbox-4">2 Star</label>
    <input type="checkbox" name="checkbox-4" id="checkbox-4">
    <label for="checkbox-5">3 Star</label>
    <input type="checkbox" name="checkbox-5" id="checkbox-5">
    <label for="checkbox-6">4 Star</label>
    <input type="checkbox" name="checkbox-6" id="checkbox-6">
    <label for="checkbox-7">5 Star</label>
    <input type="checkbox" name="checkbox-7" id="checkbox-7">
  </fieldset>
</div>

  <div class="form-group2">
  <br>
  <label>Enter your flight details</label>
    <textarea name="flightDetails" placeholder="Enter your Flight Details"></textarea> 
</div>

<div class="form-group2">
<fieldset>
    <legend>Room type: </legend>
    <label for="checkbox-8">Single</label>
    <input type="checkbox" name="checkbox-8" id="checkbox-8">
    <label for="checkbox-9">King room</label>
    <input type="checkbox" name="checkbox-9" id="checkbox-9">
    <label for="checkbox-10">Twin room</label>
    <input type="checkbox" name="checkbox-10" id="checkbox-10">
    <label for="checkbox-11">Junior Suite</label>
    <input type="checkbox" name="checkbox-11" id="checkbox-11">
    <label for="checkbox-12">Suite</label>
    <input type="checkbox" name="checkbox-12" id="checkbox-12">
  </fieldset>
</div>

<div>
  <button class= "button" type="submit" name="submit">Submit</button>
</div>
  </form>
</div> <!-- container div-->

<!-- Initialize the datepicker -->
  <script>
  $( function() {
    $( "#datepicker" ).datepicker({
      changeMonth: true,
      changeYear: true
    });
  } );
  </script>

<script>
  $( function() {
    $( "#datepicker2" ).datepicker({
      changeMonth: true,
      changeYear: true
    });
  } );
  </script>

<script>
  $( function() {
    $( "#checkbox-1" ).checkboxradio({
      icon: false
    });
  } );
  </script>

<script>
  $( function() {
    $( "#checkbox-2" ).checkboxradio({
      icon: false
    });
  } );
  </script>

<script>
  $( function() {
    $( "#checkbox-3" ).checkboxradio({
      icon: false
    });
  } );
  </script>

<script>
  $( function() {
    $( "#checkbox-4" ).checkboxradio({
      icon: false
    });
  } );
  </script>

<script>
  $( function() {
    $( "#checkbox-5" ).checkboxradio({
      icon: false
    });
  } );
  </script>

<script>
  $( function() {
    $( "#checkbox-6" ).checkboxradio({
      icon: false
    });
  } );
  </script>

<script>
  $( function() {
    $( "#checkbox-7" ).checkboxradio({
      icon: false
    });
  } );
  </script>

<script>
  $( function() {
    $( "#checkbox-8" ).checkboxradio({
      icon: false
    });
  } );
  </script>

<script>
  $( function() {
    $( "#checkbox-9" ).checkboxradio({
      icon: false
    });
  } );
  </script>

<script>
  $( function() {
    $( "#checkbox-10" ).checkboxradio({
      icon: false
    });
  } );
  </script>

<script>
  $( function() {
    $( "#checkbox-11" ).checkboxradio({
      icon: false
    });
  } );
  </script>

<script>
  $( function() {
    $( "#checkbox-12" ).checkboxradio({
      icon: false
    });
  } );
  </script>

<script>
  var input = document.querySelector("#phone");
  window.intlTelInput(input,{});
</script>

</body>